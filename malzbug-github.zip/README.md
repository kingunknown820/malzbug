# Malzbug

**Malzbug** is a custom tool-based web interface to deliver WhatsApp crash bugs using a stylized UI.  
Designed for testing or demonstration purposes only.

---

### 💻 Features:
- Login form (static)
- Target input for WhatsApp number
- Bug type selector (invisible crash, delay, etc.)
- Send action button
- Clean futuristic UI with neon glow

---

### 🚀 How to Deploy:
1. Upload to GitHub
2. Connect GitHub to [Vercel](https://vercel.com/import)
3. Done! Your link will be like `https://malzbug.vercel.app`

> 🛑 This tool is for educational & ethical testing use only. Do not misuse.

